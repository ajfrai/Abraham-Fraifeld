import argparse
import os
from collections import Counter

from keras.models import Sequential
from keras.layers import Embedding, Bidirectional, LSTM, Dense, TimeDistributed

import numpy as np
from keras import backend as K

# default args

args = argparse.ArgumentParser(description='Program description.')
args.add_argument('-d','--device', default='cpu', help='Either "cpu" or "cuda"')
args.add_argument('-e','--epochs', default=1, type=int, help='Number of epochs')
args.add_argument('-lr','--learning-rate', default=0.1, type=float, help='Learning rate')
args.add_argument('-do','--dropout', default=0.3, type=int, help='Dropout rate')
args.add_argument('-ea','--early-stopping', default=-1, type=int, help='Early stopping criteria')
args.add_argument('-em','--embedding-size', default=100, type=int, help='Embedding dimension size')
args.add_argument('-hs','--hidden-size', default=10, type=int, help='Hidden layer size')
args.add_argument('-b','--batch-size', default=50, type=int, help='Batch Size')
args = args.parse_args()




train_file = r'pos-data/a3/en-ud-train.upos.tsv'
dev_file = r'pos-data/a3/en-ud-dev.upos.tsv'
test_file = r'pos-data/a3/en-ud-test.upos.tsv'

UNK = '[UNK]'
PAD = '[PAD]'


def get_vocabulary_and_data(data_file, max_vocab_size=None):
    vocab = Counter()
    pos_vocab = {'<s>','</s>'}
    vocab[UNK] = 1
    vocab[PAD] = 1
    data = []
    gold_labels = []
    with open(data_file, 'r', encoding='utf8') as f:
        sent = ['<s>']
        sent_pos = ['<s>']
        for line in f:
            if line.strip():
                tok, pos = line.strip().split('\t')[0], line.strip().split('\t')[1]
                sent.append(tok)
                sent_pos.append(pos)
                vocab[tok]+=1
                vocab['<s>'] += 1
                vocab['</s>'] += 1
                pos_vocab.add(pos)
            elif sent:
                sent.append('</s>')
                sent_pos.append('</s>')
                sent = transform_text_sequence(sent)
                data.append(sent)
                gold_labels.append(sent_pos)
                sent = ['<s>']
                sent_pos = ['<s>']
    vocab = sorted(vocab.keys(), key = lambda k: vocab[k], reverse=True)
    if max_vocab_size:
        vocab = vocab[:len(vocab) - max_vocab_size - 4]
    vocab = [UNK, PAD] + vocab
    return {k:v for v,k in enumerate(vocab)}, list(pos_vocab), data, gold_labels


def vectorize_sequence(seq, vocab):
    seq = [tok if tok in vocab else UNK for tok in seq]
    return [vocab[tok] for tok in seq]


def unvectorize_sequence(seq, vocab):
    translate = sorted(vocab.keys(),key=lambda k:vocab[k])
    return [translate[i] for i in seq]


def one_hot_encode_label(label):
    vec = [1.0 if l==label else 0.0 for l in labels]
    return np.array(vec)


def batch_generator(data, labels, vocab, batch_size=1):
    while True:
        batch_x = []
        batch_y = []
        for sent, sent_pos in zip(data,labels):
            batch_x.append(vectorize_sequence(sent, vocab))
            batch_y.append([one_hot_encode_label(label) for label in sent_pos])
            if len(batch_x) >= batch_size:
                # Pad Sequences in batch to same length
                batch_x = pad_sequences(batch_x, vocab[PAD])
                batch_y = pad_sequences(batch_y, one_hot_encode_label(PAD))
                yield np.array(batch_x), np.array(batch_y)
                batch_x = []
                batch_y = []


def describe_data(data, gold_labels, label_set, generator):
    batch_x, batch_y = [], []
    for bx, by in generator:
        batch_x = bx
        batch_y = by
        break
    print('Data example:',data[0])
    print('Label:',gold_labels[0])
    print('Label count:', len(label_set))
    print('Batch input shape:', batch_x.shape)
    print('Batch output shape:', batch_y.shape)


def pad_sequences(batch_x, pad_value):
    ''' This function should take a batch of sequences of different lengths
        and pad them with the pad_value token so that they are all the same length.

        Assume that batch_x is a list of lists.
    '''
    pad_length = len(max(batch_x, key=lambda x: len(x)))
    for i, x in enumerate(batch_x):
        if len(x) < pad_length:
            batch_x[i] = x + ([pad_value] * (pad_length - len(x)))

    return batch_x


# TODO
def transform_text_sequence(seq):
    '''
    Implement this function if you want to transform the input text,
    for example normalizing case.
    '''
    return seq


vocab, labels, train_data, train_labels = get_vocabulary_and_data(train_file)
_, _, dev_data, dev_labels = get_vocabulary_and_data(dev_file)
_, _, test_data, test_labels = get_vocabulary_and_data(test_file)

describe_data(train_data, train_labels, labels,
              batch_generator(train_data,train_labels, vocab, args.batch_size))


# Implement your model here! ----------------------------------------------------------------------
# Use the variables args.batch_size, args.hidden_size, args.embedding_size, args.dropout, args.epochs
# You can input these as command line parameters.






# ------------------------------------------------------------------------------------------------


pos_tagger.compile(optimizer='adadelta', loss='categorical_crossentropy', metrics=['accuracy'])

# Training
pos_tagger.fit_generator(batch_generator(train_data, train_labels, vocab, args.batch_size),
                         epochs=args.epochs, steps_per_epoch=len(train_data)/args.batch_size)

# Evaluation
loss, acc = pos_tagger.evaluate_generator(batch_generator(dev_data, dev_labels, vocab),
                                          steps=len(dev_data))
print('Dev Loss:', loss, 'Dev Acc:', acc)
