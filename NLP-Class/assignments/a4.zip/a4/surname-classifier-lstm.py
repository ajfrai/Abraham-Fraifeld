import argparse
import os, random
from collections import Counter

from keras.models import Sequential
from keras.layers import Embedding, Bidirectional, LSTM, Dense
from keras.regularizers import l2

import numpy as np
from keras import backend as K

# default args

args = argparse.ArgumentParser(description='Program description.')
args.add_argument('-d','--device', default='cpu', help='Either "cpu" or "cuda"')
args.add_argument('-e','--epochs', default=10, type=int, help='Number of epochs')
args.add_argument('-lr','--learning-rate', default=0.1, type=float, help='Learning rate')
args.add_argument('-do','--dropout', default=0.3, type=int, help='Dropout rate')
args.add_argument('-ea','--early-stopping', default=-1, type=int, help='Early stopping criteria')
args.add_argument('-em','--embedding-size', default=100, type=int, help='Embedding dimension size')
args.add_argument('-hs','--hidden-size', default=10, type=int, help='Hidden layer size')
args.add_argument('-b','--batch-size', default=50, type=int, help='Batch Size')
args = args.parse_args()




data_file = r'surname-data/surnames.csv'

UNK = '[UNK]'
PAD = '[PAD]'
START = '<s>'
END = '</s>'

def get_vocabulary_and_data(data_file, split, max_vocab_size=None):
    vocab = Counter()
    data = []
    labels = []
    with open(data_file, 'r', encoding='utf8') as f:
        for line in f:
            cols = line.split(',')
            s, surname, label = cols[0].strip(), cols[1].strip(), cols[2].strip()
            if s==split:
                surname = list(surname)
                surname = [START]+surname+[END]
                data.append(transform_text_sequence(surname))
                labels.append(label)
            for tok in surname:
                vocab[tok]+=1

    vocab = sorted(vocab.keys(), key=lambda k: vocab[k], reverse=True)
    if max_vocab_size:
        vocab = vocab[:len(vocab)-max_vocab_size-4]
    vocab = [UNK, PAD] + vocab

    return {k:v for v,k in enumerate(vocab)}, set(labels), data, labels


def vectorize_sequence(seq, vocab):
    seq = [tok if tok in vocab else UNK for tok in seq]
    return [vocab[tok] for tok in seq]


def unvectorize_sequence(seq, vocab):
    translate = sorted(vocab.keys(),key=lambda k:vocab[k])
    return [translate[i] for i in seq]


def one_hot_encode_label(label):
    vec = [1.0 if l==label else 0.0 for l in labels]
    return np.array(vec)


def batch_generator(data, labels, vocab, batch_size=1):
    while True:
        batch_x = []
        batch_y = []
        for doc, label in zip(data,labels):
            batch_x.append(vectorize_sequence(doc, vocab))
            batch_y.append(one_hot_encode_label(label))
            if len(batch_x) >= batch_size:
                # Pad Sequences in batch to same length
                batch_x = pad_sequences(batch_x, vocab[PAD])
                yield np.array(batch_x), np.array(batch_y)
                batch_x = []
                batch_y = []


def describe_data(data, gold_labels, label_set, generator):
    batch_x, batch_y = [], []
    for bx, by in generator:
        batch_x = bx
        batch_y = by
        break
    print('Data example:',data[0])
    print('Label:',gold_labels[0])
    print('Label count:', len(label_set))
    print('Batch input shape:', batch_x.shape)
    print('Batch output shape:', batch_y.shape)


def pad_sequences(batch_x, pad_value):
    ''' This function should take a batch of sequences of different lengths
        and pad them with the pad_value token so that they are all the same length.

        Assume that batch_x is a list of lists.
    '''
    pad_length = len(max(batch_x, key=lambda x: len(x)))
    for i, x in enumerate(batch_x):
        if len(x) < pad_length:
            batch_x[i] = x + ([pad_value] * (pad_length - len(x)))

    return batch_x


# TODO
def transform_text_sequence(seq):
    '''
    Implement this function if you want to transform the input text,
    for example normalizing case.
    '''
    return seq


vocab, labels, train_data, train_labels = get_vocabulary_and_data(data_file, 'train')
_, _, dev_data, dev_labels = get_vocabulary_and_data(data_file, 'dev')
_, _, test_data, test_labels = get_vocabulary_and_data(data_file, 'test')

describe_data(train_data, train_labels, labels,
              batch_generator(train_data, train_labels, vocab, args.batch_size))


# Implement your model here! ----------------------------------------------------------------------
# Use the variables args.batch_size, args.hidden_size, args.embedding_size, args.dropout, args.epochs
# You can input these as command line parameters.






# ------------------------------------------------------------------------------------------------


classifier.compile(optimizer='adadelta', loss='categorical_crossentropy', metrics=['accuracy'])


# Training
classifier.fit_generator(batch_generator(train_data, train_labels, vocab, batch_size=args.batch_size),
                         epochs=args.epochs, steps_per_epoch=len(train_data)/args.batch_size)

# Evaluation
loss, acc = classifier.evaluate_generator(batch_generator(dev_data, dev_labels, vocab),
                                          steps=len(dev_data))
print('Dev Loss:', loss, 'Dev Acc:', acc)
